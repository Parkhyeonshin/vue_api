<template>
  <!-- <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/About">About</router-link>
    <router-link to="/Reference">reference</router-link>
    <router-link to="/Youtube">youtube</router-link>
    <router-link to="/Unsplash">unsplash</router-link>
  </nav> -->
  <router-view />
</template>

<style lang="scss">
@import "index.scss";
</style>
