<template>
  <div class="refer">
    <h1>This is an refer page</h1>
  </div>
</template>
