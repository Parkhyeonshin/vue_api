<template>
  <div class="unsplash">
    <h1>This is an unsplash page</h1>
  </div>
</template>
