<template>
  <div class="youtube">
    <h1>This is an youtube page</h1>
  </div>
</template>
